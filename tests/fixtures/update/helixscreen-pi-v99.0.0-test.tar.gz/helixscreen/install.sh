#!/bin/sh
# Test installer — used by unit tests for update_checker do_install logic
# Real install.sh is more complex; this exercises the extraction + invocation path.
exit 0
